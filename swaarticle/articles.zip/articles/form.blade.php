<div class="form-group {{ $errors->has('art_main_heading') ? 'has-error' : ''}}">
    <label for="art_main_heading" class="control-label">{{ 'Art Main Heading' }}</label>
    <input class="form-control" name="art_main_heading" type="text" id="art_main_heading" value="{{ $article->art_main_heading or ''}}" >
    {!! $errors->first('art_main_heading', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('art_sub_heading') ? 'has-error' : ''}}">
    <label for="art_sub_heading" class="control-label">{{ 'Art Sub Heading' }}</label>
    <input class="form-control" name="art_sub_heading" type="text" id="art_sub_heading" value="{{ $article->art_sub_heading or ''}}" >
    {!! $errors->first('art_sub_heading', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('art_author_id') ? 'has-error' : ''}}">
    <label for="art_author_id" class="control-label">{{ 'Art Author Id' }}</label>
    <select name="art_author_id" class="form-control" id="art_author_id" >
    @foreach ((App\Article::get()) as $optionKey => $optionValue)
        <option value="{{ json_encode($optionValue->id) }}" {{ (isset($article->art_author_id) && $article->art_author_id == $optionValue->id) ? 'selected' : ''}}>{{ $optionValue->art_main_heading
 }}</option>
    @endforeach
</select>


    {!! $errors->first('art_author_id', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('art_content') ? 'has-error' : ''}}">
    <label for="art_content" class="control-label">{{ 'Art Content' }}</label>
    <textarea class="form-control" rows="5" name="art_content" type="textarea" id="art_content" >{{ $article->art_content or ''}}</textarea>
    {!! $errors->first('art_content', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('art_date') ? 'has-error' : ''}}">
    <label for="art_date" class="control-label">{{ 'Art Date' }}</label>
    <input class="form-control" name="art_date" type="text" id="art_date" value="{{ $article->art_date or ''}}" >
    {!! $errors->first('art_date', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('art_category_id') ? 'has-error' : ''}}">
    <label for="art_category_id" class="control-label">{{ 'Art Category Id' }}</label>
    <select name="art_category_id" class="form-control" id="art_category_id" >
    
    @foreach ((App\Category::get()) as $optionKey => $optionValue)
        <option value="{{ json_encode($optionValue->id) }}" {{ (isset($article->art_category_id) && $article->art_category_id == $optionValue->id) ? 'selected' : ''}}>{{ $optionValue->cat_name
 }}</option>
    @endforeach
</select>
    {!! $errors->first('art_category_id', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('view') ? 'has-error' : ''}}">
    <label for="view" class="control-label">{{ 'View' }}</label>
    <input class="form-control" name="view" type="number" id="view" value="{{ $article->view or ''}}" >
    {!! $errors->first('view', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('publish') ? 'has-error' : ''}}">
    <label for="publish" class="control-label">{{ 'Publish' }}</label>
    <input class="form-control" name="publish" type="number" id="publish" value="{{ $article->publish or ''}}" >
    {!! $errors->first('publish', '<p class="help-block">:message</p>') !!}
</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="{{ $formMode === 'edit' ? 'Update' : 'Create' }}">
</div>
@section('scripts')
    <script src="{{ asset ('/bower_components/ckeditor/ckeditor.js') }}"></script>
    <script>
    $(document).ready(function() {
        $('#art_date').datepicker({
           autoclose: true
        });            
        CKEDITOR.replace('art_contect')
    });
    </script>
@endsection